public class RazorPayAdapter implements PaymentProcessor {
    private RazorPay razorpay;

    public RazorPayAdapter(RazorPay razorpay) {
        this.razorpay = razorpay;
    }

    public void processPayment(double amount) {
        razorpay.makePayment(amount);
    }

    public void refundPayment(double amount) {
        razorpay.issueRefund(amount);
    }

    public String checkPaymentStatus(String transactionId) {
        return razorpay.fetchStatus(transactionId);
    }
}
