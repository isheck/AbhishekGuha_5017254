public class AdapterPatternTest {
    public static void main(String[] args) {
        //instances of the adaptee classes
        Paytm paytm = new Paytm();
        RazorPay razorpay = new RazorPay();

        //adapter instances
        PaymentProcessor paytmAdapter = new PaytmAdapter(paytm);
        PaymentProcessor razorpayAdapter = new RazorPayAdapter(razorpay);

        // Use the adapters to process payments
        System.out.println("Using Paytm Adapter:");
        paytmAdapter.processPayment(1500.00);
        System.out.println(paytmAdapter.checkPaymentStatus("TXN16795"));
        paytmAdapter.refundPayment(500.00);

        System.out.println("\nUsing Razorpay Adapter:");
        razorpayAdapter.processPayment(2500.00);
        System.out.println(razorpayAdapter.checkPaymentStatus("TXN67530"));
        razorpayAdapter.refundPayment(1000.00);
    }
}
