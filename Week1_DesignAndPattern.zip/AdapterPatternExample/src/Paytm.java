public class Paytm {
    public void pay(double amount) {
        System.out.println("Processing payment of ₹" + amount + " through Paytm.");
    }

    public void refund(double amount) {
        System.out.println("Refunding payment of ₹" + amount + " through Paytm.");
    }

    public String getStatus(String transactionId) {
        return "Status of transaction " + transactionId + " through Paytm: SUCCESS";
    }
}
