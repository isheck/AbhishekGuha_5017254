public class RazorPay {
    public void makePayment(double amount) {
        System.out.println("Processing payment of ₹" + amount + " through Razorpay.");
    }

    public void issueRefund(double amount) {
        System.out.println("Refunding payment of ₹" + amount + " through Razorpay.");
    }

    public String fetchStatus(String transactionId) {
        return "Status of transaction " + transactionId + " through Razorpay: SUCCESS";
    }
}
