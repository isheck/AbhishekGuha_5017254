public class PaytmAdapter implements PaymentProcessor {
    private Paytm paytm;

    public PaytmAdapter(Paytm paytm) {
        this.paytm = paytm;
    }
    public void processPayment(double amount) {
        paytm.pay(amount);
    }

    public void refundPayment(double amount) {
        paytm.refund(amount);
    }

    public String checkPaymentStatus(String transactionId) {
        return paytm.getStatus(transactionId);
    }
}
