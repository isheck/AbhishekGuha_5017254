public class Computer {
    private String CPU;
    private String RAM;
    private String storage;
    private String graphicsCard;
    private String powerSupply;
    private String motherboard;
    
    //a private constructor that takes the Builder as a parameter.
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.graphicsCard = builder.graphicsCard;
        this.powerSupply = builder.powerSupply;
        this.motherboard = builder.motherboard;
    }
    
    public String getCPU() { 
        return CPU; 
    }
    public String getRAM() { 
        return RAM; 
    }
    public String getStorage() { 
        return storage; 
    }
    public String getGraphicsCard() { 
        return graphicsCard; 
    }
    public String getPowerSupply() { 
        return powerSupply; 
    }
    public String getMotherboard() { 
        return motherboard; 
    }
    //later used to test the pattern
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", storage=" + storage + ", graphicsCard=" + graphicsCard 
            + ", powerSupply=" + powerSupply + ", motherboard=" + motherboard + "]";
    }

    //a static nested Builder class inside Computer with methods to set each attribute
    public static class Builder {
        private String CPU;
        private String RAM;
        private String storage;
        private String graphicsCard;
        private String powerSupply;
        private String motherboard;
        
        public Builder(String CPU, String RAM) {
            this.CPU = CPU;
            this.RAM = RAM;
        }
        
        public Builder setStorage(String storage) {
            this.storage = storage;
            return this;
        }
        
        public Builder setGraphicsCard(String graphicsCard) {
            this.graphicsCard = graphicsCard;
            return this;
        }
                
        public Builder setPowerSupply(String powerSupply) {
            this.powerSupply = powerSupply;
            return this;
        }
        
        public Builder setMotherboard(String motherboard) {
            this.motherboard = motherboard;
            return this;
        }
        
        //a build() method in the Builder class that returns an instance of Computer.
        public Computer build() {
            return new Computer(this);
        }
    }
}
