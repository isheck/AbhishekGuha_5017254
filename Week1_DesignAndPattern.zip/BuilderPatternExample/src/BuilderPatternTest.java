public class BuilderPatternTest {
    public static void main(String[] args) {
        // Create different configurations of Computer using the Builder pattern
        Computer gamingPC = new Computer.Builder("Intel i9", "32GB")
                                .setGraphicsCard("NVIDIA RTX 3080")
                                .setStorage("1TB SSD")
                                .setPowerSupply("750W")
                                .setMotherboard("ASUS ROG")
                                .build();
        
        Computer officePC = new Computer.Builder("Intel i5", "16GB")
                                .setStorage("512GB SSD")
                                .setPowerSupply("500W")
                                .build();
        
        // Print out the configurations
        System.out.println("Gaming PC: " + gamingPC);
        System.out.println("Office PC: " + officePC);
    }
}
