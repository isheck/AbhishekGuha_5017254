public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        context.setPaymentStrategy(new CreditCardPayment("2568-1357-1479-2356"));
        context.executePayment(1000.0);

        context.setPaymentStrategy(new PayPalPayment("user@gmail.com"));
        context.executePayment(2500.0);
    }
}
