//an abstract decorator class NotifierDecorator that implements Notifier and holds a reference to a Notifier object.
public abstract class NotifierDecorator implements Notifier {
    protected Notifier notifier;

    public NotifierDecorator(Notifier notifier) {
        this.notifier = notifier;
    }
    
    public void send(String message) {
        notifier.send(message);
    }
}
