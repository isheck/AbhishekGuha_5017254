//an interface Notifier with a method send().
public interface Notifier {
    void send(String message);
}
