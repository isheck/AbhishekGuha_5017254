public class CustomerRepositoryImpl implements CustomerRepository {

    public Customer findCustomerById(String id) {
        // Simulate finding a customer by id
        return new Customer(id, "Kuntaleeka Kundu");
    }
}
