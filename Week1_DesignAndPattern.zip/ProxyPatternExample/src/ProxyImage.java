/*the ProxyImage class checks the cache (imageCache map) to see if the 
image has already been loaded. If it has not, it loads the image from 
disk and stores it in the cache. */
import java.util.HashMap;
import java.util.Map;

public class ProxyImage implements Image {
    private static Map<String, RealImage> imageCache = new HashMap<>();
    private String filename;

    public ProxyImage(String filename) {
        this.filename = filename;
    }

    public void display() {
        RealImage realImage = imageCache.get(filename);
        if (realImage == null) {
            realImage = new RealImage(filename);
            imageCache.put(filename, realImage);
        }
        realImage.display();
    }
}
