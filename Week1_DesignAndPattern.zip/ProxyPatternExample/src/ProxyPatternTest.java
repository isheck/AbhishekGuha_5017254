//a test class to demonstrate the use of ProxyImage to load and display images
public class ProxyPatternTest {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("test_image1.jpg");
        Image image2 = new ProxyImage("test_image2.jpg");

        //image will be loaded from disk
        image1.display();
        System.out.println("");

        //image will not be loaded from disk
        image1.display();
        System.out.println("");

        //image will be loaded from disk
        image2.display();
        System.out.println("");

        //image will not be loaded from disk
        image2.display();
    }
}
