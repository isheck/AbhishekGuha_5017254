public class Logger
{
    //Private Instance of Itself
    private static Logger instance;

    //Constructor of the Logger is private
    private Logger() {
    }

    //Public method to get the instance of the class
    public static Logger getInstance() {
        if(instance == null){
            instance = new Logger();
        }
        return instance;
    }

    //Method to log messages
    public void log(String message){
        System.out.println("Log:" + message);
    }
}