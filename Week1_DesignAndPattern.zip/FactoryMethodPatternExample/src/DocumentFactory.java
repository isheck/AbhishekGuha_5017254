//creating an abstract class DocumentFactory with a method createDocument().
public abstract class DocumentFactory {
    public abstract Document createDocument();
}
