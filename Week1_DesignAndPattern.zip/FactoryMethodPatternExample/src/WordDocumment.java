//creating concrete word document class
public class WordDocumment implements Document {
    public void open(){
        System.out.println("Opening The Word File");
    }
    public void close(){
        System.out.println("Closing The Word File");
    }
    public void save(){
        System.out.println("Saving the Word File");
    }
}
