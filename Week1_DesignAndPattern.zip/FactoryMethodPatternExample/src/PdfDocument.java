public class PdfDocument implements Document {
    public void open(){
        System.out.println("Opening The PDF File");
    }
    public void close(){
        System.out.println("Closing The PDF File");
    }
    public void save(){
        System.out.println("Saving the PDF File");
    }
}
