public class ExcelDocument implements Document{
    public void open(){
        System.out.println("Opening The Excel File");
    }
    public void close(){
        System.out.println("Closing The Excel File");
    }
    public void save(){
        System.out.println("Saving the Excel File");
    }
}
