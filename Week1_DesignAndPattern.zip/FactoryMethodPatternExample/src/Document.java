//interface for different document tyypes
public interface Document {

    void open();
    void close();
    void save();
}