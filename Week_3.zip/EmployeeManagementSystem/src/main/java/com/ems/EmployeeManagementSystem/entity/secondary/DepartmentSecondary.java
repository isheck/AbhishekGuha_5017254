package com.ems.EmployeeManagementSystem.entity.secondary;

import lombok.Data;

import jakarta.persistence.*;

@Data
@Entity
@Table(name = "departments_secondary")
public class DepartmentSecondary {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
}
