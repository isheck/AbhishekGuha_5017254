package com.ems.EmployeeManagementSystem.repository.secondary;

import com.ems.EmployeeManagementSystem.entity.secondary.DepartmentSecondary;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepositorySecondary extends JpaRepository<DepartmentSecondary, Long> {
    // Custom query methods
}
