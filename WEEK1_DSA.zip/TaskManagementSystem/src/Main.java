public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        Task task1 = new Task("1", "Task One", "Pending");
        Task task2 = new Task("2", "Task Two", "In Progress");
        Task task3 = new Task("3", "Task Three", "Completed");

        taskList.addTask(task1);
        taskList.addTask(task2);
        taskList.addTask(task3);

        System.out.println("Tasks after adding:");
        taskList.traverseTasks();

        System.out.println("Searching for task with ID 2:");
        Task searchResult = taskList.searchTask("2");
        System.out.println(searchResult != null ? searchResult : "Task not found.");

        System.out.println("Deleting task with ID 2:");
        taskList.deleteTask("2");
        System.out.println("Tasks after deletion:");
        taskList.traverseTasks();
    }
}
