public class FinancialForecasting {

    public static double predictFutureValue(double currentValue, double[] growthRates, int years) {
        // Base case: if no more years left to predict, return the current value
        if (years == 0) {
            return currentValue;
        }
        
        // Recursive case: apply the growth rate for the current year and call the function for the next year
        int currentYear = growthRates.length - years;
        double newValue = currentValue * (1 + growthRates[currentYear]);
        return predictFutureValue(newValue, growthRates, years - 1);
    }

    public static void main(String[] args) {
        double currentValue = 1000.0; // Initial value
        double[] growthRates = {0.05, 0.07, 0.03, 0.06}; // Past growth rates for 4 years
        int years = growthRates.length; // Number of years to predict

        double futureValue = predictFutureValue(currentValue, growthRates, years);
        System.out.println("Predicted Future Value: " + futureValue);
    }
}
