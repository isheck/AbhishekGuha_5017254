public class Main {
    public static void main(String[] args) {
        // Create Inventory instance
        Inventory inventory = new Inventory();

        // Create some products
        Product product1 = new Product("1", "Laptop", 10, 999.99);
        Product product2 = new Product("2", "Smartphone", 20, 599.99);
        Product product3 = new Product("3", "Tablet", 15, 299.99);

        // Add products to inventory
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        // Print inventory
        System.out.println("Inventory after adding products:");
        System.out.println(inventory);

        // Update a product
        inventory.updateProduct("2", "Smartphone Pro", 25, 699.99);

        // Print inventory after update
        System.out.println("Inventory after updating product 2:");
        System.out.println(inventory);

        // Delete a product
        inventory.deleteProduct("1");

        // Print inventory after deletion
        System.out.println("Inventory after deleting product 1:");
        System.out.println(inventory);
    }
}
