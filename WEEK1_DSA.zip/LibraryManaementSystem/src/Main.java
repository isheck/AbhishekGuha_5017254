public class Main {
    public static void main(String[] args) {
        LibraryManagement library = new LibraryManagement();

        Book book1 = new Book("1", "The Great Gatsby", "F. Scott Fitzgerald");
        Book book2 = new Book("2", "1984", "George Orwell");
        Book book3 = new Book("3", "To Kill a Mockingbird", "Harper Lee");
        Book book4 = new Book("4", "The Catcher in the Rye", "J.D. Salinger");

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);
        library.addBook(book4);

        System.out.println("Books in library:");
        library.printBooks();

        System.out.println("Linear search for '1984':");
        Book foundBookLinear = library.linearSearchByTitle("1984");
        System.out.println(foundBookLinear != null ? foundBookLinear : "Book not found.");

        library.sortBooksByTitle();

        System.out.println("Binary search for '1984':");
        Book foundBookBinary = library.binarySearchByTitle("1984");
        System.out.println(foundBookBinary != null ? foundBookBinary : "Book not found.");
    }
}
