public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Alice", 250.50),
            new Order("2", "Bob", 300.00),
            new Order("3", "Charlie", 150.75),
            new Order("4", "David", 500.00),
            new Order("5", "Eve", 100.25)
        };

        // Bubble Sort
        System.out.println("Orders before Bubble Sort:");
        printOrders(orders);
        BubbleSort.bubbleSort(orders);
        System.out.println("Orders after Bubble Sort:");
        printOrders(orders);

        // Reset orders array
        orders = new Order[]{
            new Order("1", "Alice", 250.50),
            new Order("2", "Bob", 300.00),
            new Order("3", "Charlie", 150.75),
            new Order("4", "David", 500.00),
            new Order("5", "Eve", 100.25)
        };

        // Quick Sort
        System.out.println("Orders before Quick Sort:");
        printOrders(orders);
        QuickSort.quickSort(orders, 0, orders.length - 1);
        System.out.println("Orders after Quick Sort:");
        printOrders(orders);
    }

    private static void printOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println(order);
        }
        System.out.println();
    }
}
