public class Main {
    public static void main(String[] args) {
        EmployeeManagement employeeManagement = new EmployeeManagement(5);

        Employee emp1 = new Employee("1", "Alice", "Manager", 75000);
        Employee emp2 = new Employee("2", "Bob", "Developer", 60000);
        Employee emp3 = new Employee("3", "Charlie", "Designer", 50000);
        Employee emp4 = new Employee("4", "David", "Tester", 45000);
        Employee emp5 = new Employee("5", "Eve", "HR", 55000);

        employeeManagement.addEmployee(emp1);
        employeeManagement.addEmployee(emp2);
        employeeManagement.addEmployee(emp3);
        employeeManagement.addEmployee(emp4);
        employeeManagement.addEmployee(emp5);

        System.out.println("Employees after adding:");
        employeeManagement.traverseEmployees();

        System.out.println("Searching for employee with ID 3:");
        Employee searchResult = employeeManagement.searchEmployee("3");
        System.out.println(searchResult != null ? searchResult : "Employee not found.");

        System.out.println("Deleting employee with ID 2:");
        employeeManagement.deleteEmployee("2");
        System.out.println("Employees after deletion:");
        employeeManagement.traverseEmployees();
    }
}
