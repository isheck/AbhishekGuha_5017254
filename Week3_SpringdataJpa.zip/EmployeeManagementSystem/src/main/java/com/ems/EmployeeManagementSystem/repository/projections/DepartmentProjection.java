package com.ems.EmployeeManagementSystem.repository.projections;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
