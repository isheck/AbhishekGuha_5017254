package com.ems.EmployeeManagementSystem.entity;

import lombok.Data;
import jakarta.persistence.*;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NaturalId;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
@Data
@Entity
@Table(name = "employees")
@NamedQuery(name = "Employee.findByName", query = "SELECT e FROM Employee e WHERE e.name = :name")
@EntityListeners(AuditingEntityListener.class)
@BatchSize(size = 20) // Hibernate-specific annotation for batch fetching
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NaturalId // Hibernate-specific annotation to mark email as a natural identifier
    private String name;
    private String email;

    @ManyToOne
    @JoinColumn(name = "department_id")
    
    private Department department;

    public void setId(Long id) 
    {
        this.id = id;
    }
    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant createdDate;

    @LastModifiedDate
    @Column(nullable = false)
    private Instant lastModifiedDate;

    @CreatedBy
    private String createdBy;

    @LastModifiedBy
    private String lastModifiedBy;
}