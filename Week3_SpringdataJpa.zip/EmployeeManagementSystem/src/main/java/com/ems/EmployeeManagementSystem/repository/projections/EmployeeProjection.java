package com.ems.EmployeeManagementSystem.repository.projections;


public interface EmployeeProjection {
    Long getId();
    String getName();
}
