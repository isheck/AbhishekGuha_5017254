package com.ems.EmployeeManagementSystem.repository;

import com.ems.EmployeeManagementSystem.entity.Department;
import com.ems.EmployeeManagementSystem.repository.projections.DepartmentProjection;
import com.ems.EmployeeManagementSystem.repository.projections.DepartmentProjectionClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Find departments that have employees with a specific ID
    List<Department> findByEmployeesId(Long employeeId);
    
    @Query("SELECT d.id AS id, d.name AS name FROM Department d")
    List<DepartmentProjection> findDepartmentProjections();
    
    @Query("SELECT new com.example.employeemanagementsystem.repository.projections.DepartmentProjectionClass(d.id, d.name) FROM Department d")
    List<DepartmentProjectionClass> findDepartmentProjectionClasses();
}

