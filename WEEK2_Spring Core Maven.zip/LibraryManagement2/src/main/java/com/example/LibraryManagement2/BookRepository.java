package com.example.LibraryManagement2;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    public void displayRepository() {
        System.out.println("Repository is being accessed.");
    }
}
